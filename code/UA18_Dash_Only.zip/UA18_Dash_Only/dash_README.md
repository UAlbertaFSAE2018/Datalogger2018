prerequisites:
#include <Adafruit_NeoPixel.h>
#include <Arduino.h>